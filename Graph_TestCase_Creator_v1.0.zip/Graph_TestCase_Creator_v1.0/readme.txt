** GUIDE FOR GRAPH TESTCASE GENERATOR **

Nmax (int) 1E5+1            Số đỉnh tối đa của đồ thị (mô tả trong đề bài)
maxval (int) 1E6+1          Trọng số cực đại của đồ thị (mô tả trong đề bài)
so_test (int) 501           Số testcase tối đa của đề bài (ghi chú: không phải số test của 1 file, mô tả trong đề bài)


** Configure the testcase generation
	Trong file "info.txt", cài đặt cấu hình cho từng file test, mỗi test là một dòng;
		Số đỉnh (nVertex)		Số cạnh (nEdge)
	Điều kiện thoả mản: 
		    nVertex >= nEdge 
		AND nEdge > (nVertex-1)/2

	Xuất test đồ thị
		Ứng với tc dòng trong file info.txt, chương trình sẽ tạo ra tc file chứa tc đồ thị mẫu
		Để xuất đồ thị có trọng số, dùng:			output_weight()
		Để xuất đồ thị không có trọng số, dùng:		output_unweight()