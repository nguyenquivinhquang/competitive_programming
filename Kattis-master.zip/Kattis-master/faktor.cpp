#include <iostream>

using namespace std;

int main() {
    int a, b;
    cin >> a >> b;

    int ans = a * (b-1);

    cout << ans + 1 << endl;
}
