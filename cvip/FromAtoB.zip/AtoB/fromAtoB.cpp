#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll a, b, res = 0;
void solve() {
	cin >> a >> b;
	if (a <= b ) cout << b - a;
	else {
		while (a > b) {
			if (a % 2 ==0) a /= 2;
			else a++;
			res++;
		}
		cout << res + b - a;
	}	
}
void write_test(){
	ll a = rand() % 100, b = rand() % 10000000;
	//if (t > 5) swap(a, b);
	cout << a << " " << b << endl;
}
signed main() {

	srand(time(NULL));	
	int testcase = 10;
	for (int t = 1; t <= testcase; t++) {
		string in = "input" + to_string(t) + ".in";
		string out = "out" + to_string(t) + ".ans";
		
		char const *input_file = in.data();		
		char const *output_file = out.data();		
		
		freopen(input_file,"r", stdin);
		freopen(output_file,"w", stdout);

		///-------------------------------------------------///
		solve();
	}
	
}
